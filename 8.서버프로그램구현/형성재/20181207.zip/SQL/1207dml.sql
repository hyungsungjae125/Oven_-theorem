insert into Member (mId,mPass,mName) values ('gdc1','1234','김');
insert into Member (mId,mPass,mName) values ('gdc2','1234','최');
insert into Member (mId,mPass,mName) values ('gdc3','1234','박');
insert into Member (mId,mPass,mName) values ('gdc4','1234','남');

insert into Notice (mNo,nTitle,nContents)values(1,'test1','test1_contents');
insert into Notice (mNo,nTitle,nContents)values(1,'test2','test2_contents');
insert into Notice (mNo,nTitle,nContents)values(2,'test3','test3_contents');
insert into Notice (mNo,nTitle,nContents)values(2,'test4','test4_contents');
insert into Notice (mNo,nTitle,nContents)values(3,'test5','test5_contents');


select * from Member;
select * from Notice;

select n.nNo, n.nTitle, n.nContents, m.mName,
       DATE_FORMAT(n.regDate, '%Y-%m-%d %H:%i') as regDate,
       DATE_FORMAT(n.modDate, '%Y-%m-%d %H:%i') as modDate
		 		 from Notice as n inner join Member as m 
            			on (n.mNo = m.mNo and m.delYn = 'N') where n.delYn = 'N';
            			
#삭제문
update Notice set delYn = 'Y', modDate = CURRENT_TIMESTAMP where nNo = 1;
#수정문
update Notice set nTitle = '{1}', nContents = '{2}', modDate = CURRENT_TIMESTAMP,mNo=2 where nNo = 1;
#삽입문
insert into Notice (mNo,nTitle,nContents)values(1,'{1}','{2}');