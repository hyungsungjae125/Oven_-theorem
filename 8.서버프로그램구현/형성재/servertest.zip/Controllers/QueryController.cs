using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using servertest.Modules;
using MySql.Data.MySqlClient;
using System.Collections;

namespace WebApiTest.Controllers
{
    
    [ApiController]
    public class InsertController : ControllerBase
    {
        [Route("api/Select")]
        [HttpGet]
        public ActionResult<ArrayList> Select()
        {
            return Query.GetSelect();
        }
        [Route("api/mNoSelect")]
        // POST api/values
        [HttpPost]
        public ActionResult<string> mNoSelect([FromForm] Notice notice)
        {
            return Query.GetmNoSelect(notice);
        }
        [Route("api/Insert")]
        // POST api/values
        [HttpPost]
        public ActionResult<bool> Insert([FromForm] Notice notice)
        {
            return Query.GetInsert(notice);
        }

        [Route("api/Update")]
        // POST api/values
        [HttpPost]
        public ActionResult<bool> Update([FromForm] Notice notice)
        {
            return Query.GetUpdate(notice);
        }

        [Route("api/Delete")]
        // POST api/values
        [HttpPost]
        public ActionResult<bool> Delete([FromForm] Notice notice)
        {
            return Query.GetDelete(notice);
        }
    }
}
