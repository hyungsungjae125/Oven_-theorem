using System;
using System.Collections;
using MySql.Data.MySqlClient;

namespace servertest.Modules
{
    public class Notice
    {
        public string nNo{get;set;}
        public string mNo{get;set;}
        public string nTitle{get;set;}
        public string nContents{get;set;}
        public string mName{get;set;}
    }
    public static class Query
    {
        public static bool GetInsert(Notice notice)
        {
            string mNo = GetmNoSelect(notice);
            if(mNo=="")
            {
                return false;
            }
            MYsql my =new MYsql();
            string sql = string.Format("insert into Notice (mNo,nTitle,nContents)values({0},'{1}','{2}');",mNo,notice.nTitle,notice.nContents);
            return my.NonQuery(sql);
/*
            if(my.NonQuery(sql)){
                return true;
            }else{
                return false;
            }
 */
        }
        public static bool GetUpdate(Notice notice)
        {
            string mNo = GetmNoSelect(notice);
            if(mNo=="")
            {
                return false;
            }
            MYsql my =new MYsql();
            string sql = string.Format("update Notice set nTitle = '{1}', nContents = '{2}', modDate = CURRENT_TIMESTAMP,mNo={3}"
                                      +" where nNo = {0};",notice.nNo,notice.nTitle,notice.nContents,mNo);
            
            if(my.NonQuery(sql)){
                return true;
            }else{
                return false;
            }
        }

        public static bool GetDelete(Notice notice)
        {
            string mNo = GetmNoSelect(notice);
            if(mNo=="")
            {
                return false;
            }
            MYsql my =new MYsql();
            string sql = string.Format("update Notice set delYn = 'Y', modDate = CURRENT_TIMESTAMP where nNo = {0};",notice.nNo);
            
            if(my.NonQuery(sql)){
                return true;
            }else{
                return false;
            }
        }
        public static ArrayList GetSelect(){
            MYsql my = new MYsql();
            string sql = "select n.nNo, n.nTitle, n.nContents, m.mName,"
            +" DATE_FORMAT(n.regDate, '%Y-%m-%d %H:%i') as regDate,"
            +" DATE_FORMAT(n.modDate, '%Y-%m-%d %H:%i') as modDate from Notice as n inner join Member as m "
            +"on (n.mNo = m.mNo and m.delYn = 'N') where n.delYn = 'N';";
            MySqlDataReader sdr = my.Reader(sql);
            ArrayList result=new ArrayList();
            
            while(sdr.Read()){
                Hashtable ht = new Hashtable();
                for(int i=0;i<sdr.FieldCount;i++){
                ht.Add(sdr.GetName(i),sdr.GetValue(i).ToString());
                }
                result.Add(ht);
            }
            return result;
        }

        public static string GetmNoSelect(Notice notice){
            MYsql my = new MYsql();
            string sql = string.Format("select mNo from Member where mName = '{0}' and delYn='N'",notice.mName);
            MySqlDataReader sdr = my.Reader(sql);
            string result ="";
            
            while(sdr.Read()){
                result=sdr.GetValue(0).ToString();
            }
            return result;
        }
    }
}