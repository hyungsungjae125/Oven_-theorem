using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace my_webapi
{
    public class Database
    {
        private MySqlConnection conn;
        private bool status;
        public Database(){
            status = Connection();
        }

        private bool Connection()
        {
            conn = new MySqlConnection();
            string server = "192.168.3.231";
            string uid = "root";
            string password = "1234";
            string database = "test";
            conn.ConnectionString = string.Format(@"server={0};user={1};password={2};database={3}",server,uid,password,database);
            try
            {
                conn.Open();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void Close()
        {
            if(status)  conn.Close();
        }
        public MySqlDataReader Reader123(string sql)
        {
            if (status)
            {
                try
                {
                    MySqlCommand comm = new MySqlCommand();
                    comm.CommandText = sql;
                    comm.Connection = conn;
                    comm.CommandType = CommandType.StoredProcedure;

                    return comm.ExecuteReader();
                }
                catch
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }
        public MySqlDataReader Reader(string sql,Hashtable ht)
        {
            if (status)
            {
                try
                {
                    MySqlCommand comm = new MySqlCommand();
                    comm.CommandText = sql;
                    comm.Connection = conn;
                    comm.CommandType = CommandType.StoredProcedure;

                    foreach(DictionaryEntry entry in ht)
                    {
                        comm.Parameters.Add(entry.Value);
                    }

                    return comm.ExecuteReader();
                }
                catch
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }

        public bool ReaderClose(MySqlDataReader sdr)
        {
            try
            {
                sdr.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool Non(string sql,Hashtable ht)
        {
            if (status)
            {
                try
                {
                    MySqlCommand comm = new MySqlCommand();
                    comm.CommandText = sql;
                    comm.Connection = conn;
                    comm.CommandType = CommandType.StoredProcedure;
                    foreach(DictionaryEntry entry in ht)
                    {
                        comm.Parameters.AddWithValue(entry.Key.ToString(),entry.Value);
                    }

                    comm.ExecuteNonQuery();
                    return true;
                }
                catch
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        
    }
}