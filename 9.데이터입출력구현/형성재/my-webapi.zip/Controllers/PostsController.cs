using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;

namespace my_webapi.Controllers
{
    
    [ApiController]
    public class PostsController : ControllerBase
    {
        [Route("posts")]
        [HttpGet]
        public ActionResult<ArrayList> Select123()
        {
            Database db = new Database();
            
            MySqlDataReader sdr = db.Reader123("sp_Posts");
            ArrayList list = new ArrayList();
            while (sdr.Read())
            {
                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    arr[i] = sdr.GetValue(i).ToString();
                }
                list.Add(arr);
            }
            db.ReaderClose(sdr);

            return list;

        }

        [Route("posts/select")]
        [HttpPost]
        public ActionResult<ArrayList> Select([FromForm] string search)
        {
            Database db = new Database();
            Hashtable ht = new Hashtable();
            ht.Add("_search",search);
            MySqlDataReader sdr = db.Reader("sp_Posts_Select",ht);
            ArrayList list = new ArrayList();
            while (sdr.Read())
            {
                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    arr[i] = sdr.GetValue(i).ToString();
                }
                list.Add(arr);
            }
            db.ReaderClose(sdr);

            return list;

        }

        [Route("posts/selectpno")]
        [HttpPost]
        public ActionResult<ArrayList> Select_pNo([FromForm] int pNo)
        {
            Database db = new Database();
            Hashtable ht = new Hashtable();
            ht.Add("_pNo",pNo);
            MySqlDataReader sdr = db.Reader("sp_Posts_pNo",ht);
            ArrayList list = new ArrayList();
            while (sdr.Read())
            {
                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    arr[i] = sdr.GetValue(i).ToString();
                }
                list.Add(arr);
            }
            db.ReaderClose(sdr);

            return list;

        }

        
        [Route("posts/insert")]
        [HttpPost]
        public ActionResult<string> Insert([FromForm] string pTitle, [FromForm] string pContents,[FromForm] string pWriter, [FromForm] string pPasswd)
        {
            Database db = new Database();
            Hashtable ht = new Hashtable();
            ht.Add("_pTitle", pTitle);
            ht.Add("_pContents", pContents);
            ht.Add("_pWriter", pWriter);
            ht.Add("_pPasswd",pPasswd );
            if (db.Non("sp_Posts_Insert", ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
        }
        [Route("posts/update")]
        [HttpPost]
        public ActionResult<string> Update([FromForm] string pNo,[FromForm] string pWriter, [FromForm] string pPasswd,[FromForm] string pContents)
        {
            Database db = new Database();
            Hashtable ht = new Hashtable();
            ht.Add("_pNo", pNo);
            ht.Add("_pWriter", pWriter);
            ht.Add("_pPasswd",pPasswd );
            ht.Add("_pContents", pContents);
            if (db.Non("sp_Posts_Update", ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
        }
        [Route("posts/delete")]
        [HttpPost]
        public ActionResult<string> Delete([FromForm] string pNo,[FromForm] string pWriter, [FromForm] string pPasswd)
        {
            Database db = new Database();
            Hashtable ht = new Hashtable();
            ht.Add("_pNo", pNo);
            ht.Add("_pWriter", pWriter);
            ht.Add("_pPasswd",pPasswd );
            if (db.Non("sp_Posts_Delete", ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
        }


    }
}
