﻿namespace Test1219
{
    partial class Form_detail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_title = new System.Windows.Forms.Label();
            this.panel_head = new System.Windows.Forms.Panel();
            this.label_contetns = new System.Windows.Forms.Label();
            this.textBox_contents = new System.Windows.Forms.TextBox();
            this.label_writer = new System.Windows.Forms.Label();
            this.textBox_writer = new System.Windows.Forms.TextBox();
            this.textBox_pw = new System.Windows.Forms.TextBox();
            this.label_pw = new System.Windows.Forms.Label();
            this.button_list = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.button_delete = new System.Windows.Forms.Button();
            this.button_updateok = new System.Windows.Forms.Button();
            this.button_back = new System.Windows.Forms.Button();
            this.button_deleteok = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // label_title
            // 
            this.label_title.AutoSize = true;
            this.label_title.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_title.Location = new System.Drawing.Point(12, 9);
            this.label_title.Name = "label_title";
            this.label_title.Size = new System.Drawing.Size(79, 32);
            this.label_title.TabIndex = 0;
            this.label_title.Text = "label1";
            // 
            // panel_head
            // 
            this.panel_head.BackColor = System.Drawing.Color.Black;
            this.panel_head.Location = new System.Drawing.Point(0, 44);
            this.panel_head.Name = "panel_head";
            this.panel_head.Size = new System.Drawing.Size(472, 1);
            this.panel_head.TabIndex = 1;
            // 
            // label_contetns
            // 
            this.label_contetns.AutoSize = true;
            this.label_contetns.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_contetns.Location = new System.Drawing.Point(13, 52);
            this.label_contetns.Name = "label_contetns";
            this.label_contetns.Size = new System.Drawing.Size(50, 16);
            this.label_contetns.TabIndex = 2;
            this.label_contetns.Text = "내용 :";
            // 
            // textBox_contents
            // 
            this.textBox_contents.Location = new System.Drawing.Point(12, 71);
            this.textBox_contents.Multiline = true;
            this.textBox_contents.Name = "textBox_contents";
            this.textBox_contents.Size = new System.Drawing.Size(447, 130);
            this.textBox_contents.TabIndex = 3;
            // 
            // label_writer
            // 
            this.label_writer.AutoSize = true;
            this.label_writer.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_writer.Location = new System.Drawing.Point(15, 205);
            this.label_writer.Name = "label_writer";
            this.label_writer.Size = new System.Drawing.Size(66, 16);
            this.label_writer.TabIndex = 4;
            this.label_writer.Text = "작성자 :";
            // 
            // textBox_writer
            // 
            this.textBox_writer.Location = new System.Drawing.Point(12, 224);
            this.textBox_writer.Multiline = true;
            this.textBox_writer.Name = "textBox_writer";
            this.textBox_writer.Size = new System.Drawing.Size(447, 39);
            this.textBox_writer.TabIndex = 5;
            // 
            // textBox_pw
            // 
            this.textBox_pw.Location = new System.Drawing.Point(12, 286);
            this.textBox_pw.Multiline = true;
            this.textBox_pw.Name = "textBox_pw";
            this.textBox_pw.Size = new System.Drawing.Size(447, 39);
            this.textBox_pw.TabIndex = 7;
            // 
            // label_pw
            // 
            this.label_pw.AutoSize = true;
            this.label_pw.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_pw.Location = new System.Drawing.Point(15, 267);
            this.label_pw.Name = "label_pw";
            this.label_pw.Size = new System.Drawing.Size(82, 16);
            this.label_pw.TabIndex = 6;
            this.label_pw.Text = "비밀번호 :";
            // 
            // button_list
            // 
            this.button_list.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button_list.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_list.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_list.ForeColor = System.Drawing.Color.White;
            this.button_list.Location = new System.Drawing.Point(247, 276);
            this.button_list.Name = "button_list";
            this.button_list.Size = new System.Drawing.Size(65, 45);
            this.button_list.TabIndex = 8;
            this.button_list.Text = "목록";
            this.button_list.UseVisualStyleBackColor = false;
            // 
            // button_update
            // 
            this.button_update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_update.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_update.ForeColor = System.Drawing.Color.White;
            this.button_update.Location = new System.Drawing.Point(322, 276);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(65, 45);
            this.button_update.TabIndex = 9;
            this.button_update.Text = "수정";
            this.button_update.UseVisualStyleBackColor = false;
            // 
            // button_delete
            // 
            this.button_delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_delete.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_delete.ForeColor = System.Drawing.Color.White;
            this.button_delete.Location = new System.Drawing.Point(397, 276);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(65, 45);
            this.button_delete.TabIndex = 10;
            this.button_delete.Text = "삭제";
            this.button_delete.UseVisualStyleBackColor = false;
            // 
            // button_updateok
            // 
            this.button_updateok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button_updateok.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_updateok.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_updateok.ForeColor = System.Drawing.Color.White;
            this.button_updateok.Location = new System.Drawing.Point(322, 339);
            this.button_updateok.Name = "button_updateok";
            this.button_updateok.Size = new System.Drawing.Size(65, 45);
            this.button_updateok.TabIndex = 11;
            this.button_updateok.Text = "확인";
            this.button_updateok.UseVisualStyleBackColor = false;
            // 
            // button_back
            // 
            this.button_back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.button_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_back.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_back.ForeColor = System.Drawing.Color.White;
            this.button_back.Location = new System.Drawing.Point(397, 339);
            this.button_back.Name = "button_back";
            this.button_back.Size = new System.Drawing.Size(65, 45);
            this.button_back.TabIndex = 12;
            this.button_back.Text = "취소";
            this.button_back.UseVisualStyleBackColor = false;
            // 
            // button_deleteok
            // 
            this.button_deleteok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button_deleteok.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_deleteok.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_deleteok.ForeColor = System.Drawing.Color.White;
            this.button_deleteok.Location = new System.Drawing.Point(322, 339);
            this.button_deleteok.Name = "button_deleteok";
            this.button_deleteok.Size = new System.Drawing.Size(65, 45);
            this.button_deleteok.TabIndex = 13;
            this.button_deleteok.Text = "확인";
            this.button_deleteok.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(-2, 269);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(472, 1);
            this.panel1.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(0, 331);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(472, 1);
            this.panel2.TabIndex = 3;
            // 
            // Form_detail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(471, 391);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button_deleteok);
            this.Controls.Add(this.button_back);
            this.Controls.Add(this.button_updateok);
            this.Controls.Add(this.button_delete);
            this.Controls.Add(this.button_update);
            this.Controls.Add(this.button_list);
            this.Controls.Add(this.textBox_pw);
            this.Controls.Add(this.label_pw);
            this.Controls.Add(this.textBox_writer);
            this.Controls.Add(this.label_writer);
            this.Controls.Add(this.textBox_contents);
            this.Controls.Add(this.label_contetns);
            this.Controls.Add(this.panel_head);
            this.Controls.Add(this.label_title);
            this.Name = "Form_detail";
            this.Text = "Form_detail";
            this.Load += new System.EventHandler(this.Form_detail_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_title;
        private System.Windows.Forms.Panel panel_head;
        private System.Windows.Forms.Label label_contetns;
        private System.Windows.Forms.TextBox textBox_contents;
        private System.Windows.Forms.Label label_writer;
        private System.Windows.Forms.TextBox textBox_writer;
        private System.Windows.Forms.TextBox textBox_pw;
        private System.Windows.Forms.Label label_pw;
        private System.Windows.Forms.Button button_list;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Button button_updateok;
        private System.Windows.Forms.Button button_back;
        private System.Windows.Forms.Button button_deleteok;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}