﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Test1219.Modules;

namespace Test1219
{
    public partial class Form_insert : Form
    {
        WebAPI api;
        public Form_insert()
        {
            InitializeComponent();
            Load += Form_insert_Load;
        }

        private void Form_insert_Load(object sender, EventArgs e)
        {
            button_insertok.Click += Button_insertok_Click;
            button_back.Click += Button_back_Click;
        }

        private void Button_back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button_insertok_Click(object sender, EventArgs e)
        {
            api = new WebAPI();
            Hashtable ht = new Hashtable();
            ht.Add("pTitle",textBox_title.Text);
            ht.Add("pContents", textBox_contents.Text);
            ht.Add("pWriter", textBox_writer.Text);
            ht.Add("pPasswd", textBox_pw.Text);
            if(api.Post("http://192.168.3.17:5000/posts/insert", ht))
            {
                this.Close();
            }
        }
    }
}
