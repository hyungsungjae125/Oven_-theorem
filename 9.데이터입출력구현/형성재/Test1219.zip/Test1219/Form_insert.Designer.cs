﻿namespace Test1219
{
    partial class Form_insert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.button_insertok = new System.Windows.Forms.Button();
            this.button_back = new System.Windows.Forms.Button();
            this.textBox_pw = new System.Windows.Forms.TextBox();
            this.label_pw = new System.Windows.Forms.Label();
            this.textBox_writer = new System.Windows.Forms.TextBox();
            this.label_writer = new System.Windows.Forms.Label();
            this.textBox_contents = new System.Windows.Forms.TextBox();
            this.label_contetns = new System.Windows.Forms.Label();
            this.panel_head = new System.Windows.Forms.Panel();
            this.label_title = new System.Windows.Forms.Label();
            this.textBox_title = new System.Windows.Forms.TextBox();
            this.label_title2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(-1, 388);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(472, 1);
            this.panel2.TabIndex = 17;
            // 
            // button_insertok
            // 
            this.button_insertok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button_insertok.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_insertok.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_insertok.ForeColor = System.Drawing.Color.White;
            this.button_insertok.Location = new System.Drawing.Point(321, 396);
            this.button_insertok.Name = "button_insertok";
            this.button_insertok.Size = new System.Drawing.Size(65, 45);
            this.button_insertok.TabIndex = 24;
            this.button_insertok.Text = "확인";
            this.button_insertok.UseVisualStyleBackColor = false;
            // 
            // button_back
            // 
            this.button_back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_back.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_back.ForeColor = System.Drawing.Color.White;
            this.button_back.Location = new System.Drawing.Point(396, 396);
            this.button_back.Name = "button_back";
            this.button_back.Size = new System.Drawing.Size(65, 45);
            this.button_back.TabIndex = 23;
            this.button_back.Text = "취소";
            this.button_back.UseVisualStyleBackColor = false;
            // 
            // textBox_pw
            // 
            this.textBox_pw.Location = new System.Drawing.Point(11, 343);
            this.textBox_pw.Multiline = true;
            this.textBox_pw.Name = "textBox_pw";
            this.textBox_pw.Size = new System.Drawing.Size(447, 39);
            this.textBox_pw.TabIndex = 22;
            // 
            // label_pw
            // 
            this.label_pw.AutoSize = true;
            this.label_pw.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_pw.Location = new System.Drawing.Point(14, 324);
            this.label_pw.Name = "label_pw";
            this.label_pw.Size = new System.Drawing.Size(82, 16);
            this.label_pw.TabIndex = 21;
            this.label_pw.Text = "비밀번호 :";
            // 
            // textBox_writer
            // 
            this.textBox_writer.Location = new System.Drawing.Point(11, 281);
            this.textBox_writer.Multiline = true;
            this.textBox_writer.Name = "textBox_writer";
            this.textBox_writer.Size = new System.Drawing.Size(447, 39);
            this.textBox_writer.TabIndex = 20;
            // 
            // label_writer
            // 
            this.label_writer.AutoSize = true;
            this.label_writer.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_writer.Location = new System.Drawing.Point(14, 262);
            this.label_writer.Name = "label_writer";
            this.label_writer.Size = new System.Drawing.Size(66, 16);
            this.label_writer.TabIndex = 19;
            this.label_writer.Text = "작성자 :";
            // 
            // textBox_contents
            // 
            this.textBox_contents.Location = new System.Drawing.Point(11, 128);
            this.textBox_contents.Multiline = true;
            this.textBox_contents.Name = "textBox_contents";
            this.textBox_contents.Size = new System.Drawing.Size(447, 130);
            this.textBox_contents.TabIndex = 18;
            // 
            // label_contetns
            // 
            this.label_contetns.AutoSize = true;
            this.label_contetns.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_contetns.Location = new System.Drawing.Point(12, 109);
            this.label_contetns.Name = "label_contetns";
            this.label_contetns.Size = new System.Drawing.Size(50, 16);
            this.label_contetns.TabIndex = 16;
            this.label_contetns.Text = "내용 :";
            // 
            // panel_head
            // 
            this.panel_head.BackColor = System.Drawing.Color.Black;
            this.panel_head.Location = new System.Drawing.Point(-1, 43);
            this.panel_head.Name = "panel_head";
            this.panel_head.Size = new System.Drawing.Size(472, 1);
            this.panel_head.TabIndex = 15;
            // 
            // label_title
            // 
            this.label_title.AutoSize = true;
            this.label_title.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_title.Location = new System.Drawing.Point(11, 8);
            this.label_title.Name = "label_title";
            this.label_title.Size = new System.Drawing.Size(87, 32);
            this.label_title.TabIndex = 14;
            this.label_title.Text = "글작성";
            // 
            // textBox_title
            // 
            this.textBox_title.Location = new System.Drawing.Point(11, 67);
            this.textBox_title.Multiline = true;
            this.textBox_title.Name = "textBox_title";
            this.textBox_title.Size = new System.Drawing.Size(447, 39);
            this.textBox_title.TabIndex = 26;
            // 
            // label_title2
            // 
            this.label_title2.AutoSize = true;
            this.label_title2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_title2.Location = new System.Drawing.Point(14, 48);
            this.label_title2.Name = "label_title2";
            this.label_title2.Size = new System.Drawing.Size(50, 16);
            this.label_title2.TabIndex = 25;
            this.label_title2.Text = "제목 :";
            // 
            // Form_insert
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(471, 448);
            this.Controls.Add(this.textBox_title);
            this.Controls.Add(this.label_title2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button_insertok);
            this.Controls.Add(this.button_back);
            this.Controls.Add(this.textBox_pw);
            this.Controls.Add(this.label_pw);
            this.Controls.Add(this.textBox_writer);
            this.Controls.Add(this.label_writer);
            this.Controls.Add(this.textBox_contents);
            this.Controls.Add(this.label_contetns);
            this.Controls.Add(this.panel_head);
            this.Controls.Add(this.label_title);
            this.Name = "Form_insert";
            this.Text = "Form_insert";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button_insertok;
        private System.Windows.Forms.Button button_back;
        private System.Windows.Forms.TextBox textBox_pw;
        private System.Windows.Forms.Label label_pw;
        private System.Windows.Forms.TextBox textBox_writer;
        private System.Windows.Forms.Label label_writer;
        private System.Windows.Forms.TextBox textBox_contents;
        private System.Windows.Forms.Label label_contetns;
        private System.Windows.Forms.Panel panel_head;
        private System.Windows.Forms.Label label_title;
        private System.Windows.Forms.TextBox textBox_title;
        private System.Windows.Forms.Label label_title2;
    }
}