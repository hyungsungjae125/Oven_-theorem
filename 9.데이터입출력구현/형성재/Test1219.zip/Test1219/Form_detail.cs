﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test1219
{
    public partial class Form_detail : Form
    {
        public Form_detail()
        {
            InitializeComponent();
        }

        private void Form_detail_Load(object sender, EventArgs e)
        {
            this.Size = new Size(487, 370);
            button_list.Click += Button_list_Click;
            button_update.Click += Button_update_Click;
            button_delete.Click += Button_delete_Click;
            button_updateok.Click += Button_updateok_Click;
            button_deleteok.Click += Button_deleteok_Click;
            button_back.Click += Button_back_Click;
        }

        private void Button_list_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button_update_Click(object sender, EventArgs e)
        {
            this.Size = new Size(487, 430);
        }

        private void Button_delete_Click(object sender, EventArgs e)
        {
            this.Size = new Size(487, 430);
        }

        private void Button_updateok_Click(object sender, EventArgs e)
        {
            
        }

        private void Button_deleteok_Click(object sender, EventArgs e)
        {
            
        }

        private void Button_back_Click(object sender, EventArgs e)
        {
            this.Size = new Size(487, 370);
        }
    }
}
