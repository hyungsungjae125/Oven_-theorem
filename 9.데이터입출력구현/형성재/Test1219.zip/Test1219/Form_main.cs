﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Test1219.Modules;

namespace Test1219
{
    public partial class Form_main : Form
    {
        private WebAPI api;
        public Form_main()
        {
            
            InitializeComponent();
            Load += Form_main_Load;
        }

        private void Form_main_Load(object sender, EventArgs e)
        {
            button_insert.Click += Button_insert_Click;
            button_search.Click += Button_search_Click;
            ListPrint();


        }

        private void ListPrint()
        {
            api = new WebAPI();
            Hashtable ht = new Hashtable();
            //ht.Add("search", textBox_search.Text);
            api.ListView("http://192.168.3.17:5000/posts", listView_Posts,ht);
        }

        private void Button_search_Click(object sender, EventArgs e)
        {
            MessageBox.Show("검색");
        }

        private void Button_insert_Click(object sender, EventArgs e)
        {
            Form_insert fi = new Form_insert();
            fi.FormClosed += Fi_FormClosed;
            fi.StartPosition = FormStartPosition.CenterParent;
            fi.ShowDialog();
        }

        private void Fi_FormClosed(object sender, FormClosedEventArgs e)
        {
            ListPrint();
        }
    }
}
