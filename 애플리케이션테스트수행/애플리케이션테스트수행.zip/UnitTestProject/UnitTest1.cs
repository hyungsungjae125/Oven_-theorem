﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using _20181123;
using System.Data.SqlClient;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        MSsql db;
        [TestMethod]
        public void TestMethod_DBConnect()
        {
            db = new MSsql();
            Assert.AreEqual(true, db.status);
        }

        [TestMethod]
        public void TestMethod_DBClosed()
        {
            db = new MSsql();
            bool close = db.ConnectionClose();
            Assert.AreEqual(true, close);
        }

        [TestMethod]
        public void TestMethod_DBNon()
        {
            db = new MSsql();
            bool non = db.NonQuery("insert into Member (mID, mPass, mName) values ('{0}','{1}','{2}');");
            Assert.AreEqual(true, non);
        }

        [TestMethod]
        public void TestMethod_DBReader()
        {
            db = new MSsql();
            SqlDataReader sdr = db.Reader("select * from Member;");
            int cnt = 0;
            while (sdr.Read())
            {
                cnt++;
            }
            Assert.AreEqual(9,cnt);
        }

        [TestMethod]
        public void TestMethod_SelectMember()
        {
            db = new MSsql();
            UserView uv = new UserView(new UserForm(db),db);
            int count = uv.SelectData();
            Assert.AreEqual(6, count);
        }

        [TestMethod]
        public void TestMethod_InsertMember()
        {
            db = new MSsql();
            UserView uv = new UserView(new UserForm(db), db);
            int count = uv.SelectData();
            uv.InsertData();
            int result = uv.SelectData();
            Assert.AreEqual(count+1, result);
        }

        [TestMethod]
        public void TestMethod_UpdateMember()
        {
            db = new MSsql();
            UserView uv = new UserView(new UserForm(db), db);
            bool updateresult = uv.UpdateData();
            Assert.AreEqual(true,updateresult);
        }

        [TestMethod]
        public void TestMethod_DeleteMember()
        {
            db = new MSsql();
            UserView uv = new UserView(new UserForm(db), db);
            bool deleteresult = uv.DeleteData();
            Assert.AreEqual(true, deleteresult);
        }

        [TestMethod]
        public void TestMethod_SelectRule()
        {
            db = new MSsql();
            RuleView rv = new RuleView(new RuleForm(db), db);
            int count = rv.SelectData();
            Assert.AreEqual(8, count);
        }

        [TestMethod]
        public void TestMethod_InsertRule()
        {
            db = new MSsql();
            RuleView rv = new RuleView(new RuleForm(db), db);
            int count = rv.SelectData();
            rv.textBox2.Text = "이름";
            rv.InsertData();
            int result = rv.SelectData();
            Assert.AreEqual(count + 1, result);
        }

        [TestMethod]
        public void TestMethod_UpdateRule()
        {
            db = new MSsql();
            RuleView rv = new RuleView(new RuleForm(db), db);
            bool updateresult = rv.UpdateData();
            Assert.AreEqual(true, updateresult);
        }

        [TestMethod]
        public void TestMethod_DeleteRule()
        {
            db = new MSsql();
            RuleView rv = new RuleView(new RuleForm(db), db);
            rv.textBox1.Text = "2002";
            bool deleteresult = rv.DeleteData();
            Assert.AreEqual(true, deleteresult);
        }

        [TestMethod]
        public void TestMethod_SMem()
        {
            db = new MSsql();
            MappingView mv = new MappingView(new MappingForm(db), db);
            int count = mv.SelectMember();
            Assert.AreEqual(6, count);
        }

        [TestMethod]
        public void TestMethod_SRule()
        {
            db = new MSsql();
            MappingView mv = new MappingView(new MappingForm(db), db);
            int count = mv.SelectRule();
            Assert.AreEqual(3, count);
        }

        [TestMethod]
        public void TestMethod_SMap()
        {
            db = new MSsql();
            MappingView mv = new MappingView(new MappingForm(db), db);
            int count = mv.SelectMapping();
            Assert.AreEqual(3, count);
        }

        [TestMethod]
        public void TestMethod_MapInsert()
        {
            db = new MSsql();
            MappingView mv = new MappingView(new MappingForm(db), db);
            mv.textBox1.Text = "2009";
            mv.textBox2.Text = "2003";
            bool result = mv.btn1_click();
            Assert.AreEqual(true,result);
        }
    }
}
